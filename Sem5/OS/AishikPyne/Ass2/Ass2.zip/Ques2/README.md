* `caller1.c` and `caller2.c` files implement the telephonic conversation (using FIFO). Run them on differnt terminals
* `conference.c` implements a Conference call (using FIFO)
